package com.example.covid19_tracker;

import java.util.List;

public class Response{
	private List<StatewiseItem> statewise;

	public List<StatewiseItem> getStatewise(){
		return statewise;
	}
}