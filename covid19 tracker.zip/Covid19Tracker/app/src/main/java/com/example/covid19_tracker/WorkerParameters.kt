package com.example.covid19_tracker

class WorkerParameters {

}
